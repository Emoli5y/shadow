var getUrl=window.location;var baseUrl=window.location.origin;var homeText="Roblox Scripts - Rscripts, The #1 Free Roblox Script Provider!";var trendingText="Trending - Find the best, trending Roblox Scripts of this month!";var popularText="Popular - Find the most popular Roblox Scripts of the past 3 months!";var uploadText="Upload Roblox Scripts - Rscripts.net";var savedText="Saved Script | Rscripts.net";var loginText="Login | Rscripts.net";var imprintText="Imprint | Rscripts.net";var privacyText="Privacy | Rscripts.net";var usersText="Users | Rscripts.net"
var contactText="Contact | Rscripts.net";var tosText="Terms of Service | Rscripts.net";var url=window.location.href
var id=url.split("-").pop()
let commentStart=0
let commentLimit=5
var searchMod=false;const route=(event)=>{event=event||window.event;event.preventDefault();let activeLink=document.querySelector(".active");if(activeLink){activeLink.classList.remove("active");}
if(event.target.matches("i")||event.target.matches(".nav-link")){let closestNavItem=event.target.closest(".nav-item");closestNavItem?closestNavItem.classList.add("active"):null;}
window.history.pushState({},"",event.target.closest("a").href);handleLocation();};let lastRequest=0;let cache={};let stale=false;const handleLocation=async()=>{NProgress.start();const path=window.location.pathname;if(cache[path]){if(stale){updateContent(cache[path],true);regeneratePage(path);}else{updateContent(cache[path],false);}}else{lastRequest=Date.now();stale=false;fetch(path).then(response=>response.text()).then(data=>{cache[path]=data;updateContent(data,false);});}};const updateContent=(data,stale)=>{let parser=new DOMParser();let doc=parser.parseFromString(data,"text/html");document.title=doc.title;let mainPage=document.getElementById("main-page");mainPage.innerHTML=doc.getElementById("main-page").innerHTML;if(!stale){NProgress.done();}
let pathname=window.location.pathname;if(pathname==="/trending"){loadTrending();}
if(pathname==="/users"){$(".googleAd3").each(function(){$(this).append('<ins class="adsbygoogle" style="display:inline-block;width:300px;height:250px" data-ad-client="ca-pub-2192724296802940" data-ad-slot="7018771086"></ins>');(adsbygoogle=window.adsbygoogle||[]).push({});});$(".bottomAd").each(function(){$(this).append('<ins class="adsbygoogle responsiveAd" style="display:block" data-ad-client="ca-pub-2192724296802940" data-ad-slot="2260047238"></ins>');$(document).ready(function(){(adsbygoogle=window.adsbygoogle||[]).push({})})});loadUsers();}
if(pathname==="/"||pathname==="/index"){loadContent();}
if(pathname==="/saved"){loadSaved();}
if(pathname==="/upload"){loadUpload();}
if(window.location.href.indexOf("/u/")>-1){loadUser();}
if(window.location.href.indexOf("/script/")>-1){loadComments(commentStart,commentLimit);loadScriptAds(2);scriptButton();loadTitle();}
window.scrollTo(0,0);}
const regeneratePage=(route)=>{stale=false;fetch(route).then(response=>response.text()).then(data=>{cache[route]=data;stale=false;updateContent(data,false);}).catch(error=>{console.log(error);stale=true;});}
window.onpopstate=handleLocation;window.route=route;handleLocation();function loadTasks(){waitForElm('#main-page').then((elm)=>{$.post("/postHandler",{countNotifications:1}).done(function(msg){let notificationAmount=$("#notyAmount");if(msg>0){notificationAmount.show();notificationAmount.html(msg);}else{notificationAmount.hide();}})})}
function removeNavActive(){$(".nav-item").removeClass("active");}
$(document).ready(function(){loadScriptAds(5);let intervalId;$(document).on("visibilitychange",function(){if(document.hidden){clearInterval(intervalId);}else{intervalId=setInterval(loadTasks,3500);}});if(!document.hidden){intervalId=setInterval(loadTasks,3500);}
const currentUrl=window.location.pathname;const navItems=document.querySelectorAll('.nav-item a');for(const navItem of navItems){const navItemHref=navItem.getAttribute('href');if(navItemHref===currentUrl){navItem.parentElement.classList.add('active');}}
$("img").on("error",function(){$(this).attr("src","https://rscripts.net/unavailable.webp");});let notificationBox=$("#notificationBox");let notifSpinner=$("#notificationSpinner");let notifHolder=$("#notificationHolder");$("#notifications").on("click",function(){var container=$("#notificationList");container.toggleClass("hidden show")
notificationBox.hide();notifSpinner.css('display','flex');if($("#notificationList").hasClass("show")){$.post("/postHandler",{notifications:1}).done(function(msg){if(msg=="000"){notifHolder.html("<p class='text-center mt-5'>no notifications</p>");}else{notifHolder.html(msg);$(".notificationAmount").hide();}
notifSpinner.hide();notificationBox.show();})}})
$("#markAsRead").on("click",function(){$.post("/postHandler",{deleteNotifications:1}).done(function(msg){if(msg=="success"){notifHolder.empty();notifHolder.html("<p class='text-center mt-5'>no notifications</p>");toast("Notifications Deleted","successToast");}})
return false;})
$(document).mouseup(function(e){var container=$("#notificationList");var bell=$("#notifications");if(container.hasClass("show")){if(!container.is(e.target)&&container.has(e.target).length===0&&!bell.is(e.target)&&bell.has(e.target).length===0){container.toggleClass("hidden show")}}})})
function loadScript(){NProgress.start();waitForElm('#scriptframe').then((elm)=>{document.title=$("#title");$.ajax({url:baseUrl.concat("/scriptReceive"),method:"POST",data:{id:id},cache:false,success:function(data){var divs=data.split('----');$('#scriptframe').hide().html(divs[0]).fadeIn('slow');;$('#features').hide().html(divs[1]).fadeIn('slow');$('#download').hide().attr("href",(divs[2])).fadeIn('slow');if(data!==''){document.title=$("#title").html().concat(" - Roblox Scripts");$('meta[name=description]').attr('content',$("#description").html());scriptButton();$("#modalTitle").text($("#title").text());NProgress.done();}else{}}});})}
var limit=16;var start=0;$(document).on("click",".result .resultList .content h6",function(){$(this).parents(".search-box").find('input[type="text"]').val($(this).text());$(this).parent(".result").empty();});function loadTrending(){loadScriptsTemplate();loadScriptAds(1);document.title=trendingText;waitForElm('#scriptgrid').then((elm)=>{loadLayout();$.ajax({url:"/backend",method:"POST",data:{trending:1},cache:false,success:function(data){let obj=JSON.parse(data)
var item=obj.output;$('#scriptgrid').empty();$('#scriptgrid').append('<div class="ellipse d-none d-lg-block"></div>');$('#scriptgrid').append(item);if(obj.output!==''){action='active';}else{toast("Something went wrong, we're sorry!","errorToast");NProgress.start();}}})})}
function loadScriptsTemplate(){const scriptgrid=document.getElementById('scriptgrid');const templateGrid=document.getElementById('template-grid');for(let i=0;i<16;i++){scriptgrid.append(templateGrid.content.cloneNode(true));}}
function loadUserTemplate(){const allusers=document.getElementById('allusers');const templateGrid=document.getElementById('template-grid');for(let i=0;i<18;i++){allusers.append(templateGrid.content.cloneNode(true));}}
function loadSaved(){NProgress.start();loadScriptsTemplate();loadScriptAds(1);document.title=savedText;waitForElm('#scriptgrid').then((elm)=>{var limit=16;var start=0;$("#spinner").show();function loadSavedScripts(limit,start){$.post("/backend",{saved:1,start:start,limit:limit}).done(function(msg){let obj=JSON.parse(msg)
if(obj.auth=="no"){loadLogin();}else{if(obj.output==000){$("#loadMore").toggleClass("btn-primary shadow-primary btn-danger shadow-danger");$("#loadMore").text("There aren't any more posts");$("#loadMore").prop("disabled",true);}else{$('#scriptgrid').empty();$('#scriptgrid').append(obj.output);$("#loadMore").text("Show More");}
$("#spinner").hide();if(obj.num<16){$("#loadMore").hide();}
if(obj.num==0){$(".script").remove()
$("#nothingSaved").show();$("#loadMore").hide();$("#savedHeading").hide();}}
NProgress.done();})}
loadSavedScripts(limit,start)
$("#loadMore").on('click',function(){let button=$(this)
button.text("Loading...");button.prop("disabled",true)
action='active';start=start+limit;$('#spinner').show();loadSavedScripts(limit,start);$('#spinner').hide();button.prop("disabled",false)})})}
function loadLogin(){window.history.pushState({},"","/login");handleLocation();}
function loadPopular(){NProgress.start();$("#main-page").load(baseUrl.concat("/popular #main-page > *"),function(){loadScriptsTemplate();NProgress.done();loadScriptAds(1)
document.title=popularText;waitForElm('#scriptgrid').then((elm)=>{$("#spinner").show();$.ajax({url:"/backend",method:"POST",data:{popular:1},cache:false,success:function(data){let obj=JSON.parse(data)
var item=obj.output;$('#scriptgrid').empty();$('#scriptgrid').append(item);if(obj.output!==''){action='active';}else{alert("Something went wrong, we're sorry!");}
$("#spinner").hide();}})})})}
function loadUsers(){document.title=usersText;loadUserTemplate();let memberCount=$("#member-count");NProgress.start();const userHolder=$("#allusers");$.post("/postHandler",{loadUsers:1}).done(function(msg){let obj=JSON.parse(msg);$(".user-template").remove();userHolder.append(obj.data);memberCount.html(obj.total_users);$("#total_members").show();NProgress.done();})
const memberSearchInput=$('#membersearch')
let debounceTimer;memberSearchInput.on('keyup',()=>{clearTimeout(debounceTimer);debounceTimer=setTimeout(()=>{const searchTerm=memberSearchInput.val();if($("p.h2.text-center.mt-5").length){$("p.h2.text-center.mt-5").remove();}
userHolder.empty();loadUserTemplate();NProgress.start();$.post('/postHandler',{loadUsers:1,searchUser:searchTerm},(msg)=>{let obj=JSON.parse(msg);userHolder.empty();if(obj.total_users<1){$("<p class='h2 text-center mt-5'>No users found 😔</p>").insertAfter("#holder");}else{userHolder.append(obj.data);}
NProgress.done();});},250);});}
function loadLearn(){NProgress.start();document.title="Learn Roblox Exploit Scripting | Rscripts.net";$("#main-page").load(baseUrl.concat("/learn #main-page > *"),()=>{NProgress.done();})}
function loadGuide(){NProgress.start();document.title="Learn Roblox Exploit Scripting | Rscripts.net";$("#main-page").load(baseUrl.concat("/guide #main-page > *"),()=>{if(typeof someObject=='undefined')$.loadScript('/assets/js/prism.js',function(){});NProgress.done();})}
function loadUpload(){NProgress.start();loadFormAdjustments();$("#universalScript").change(function(){if(this.checked){$("#gamelink").prop("disabled",true)}else{$("#gamelink").prop("disabled",false)}})
if(typeof someObject=='undefined')$.loadScript('https://challenges.cloudflare.com/turnstile/v0/api.js',function(){turnstile.render('#cf-container',{sitekey:'0x4AAAAAAADMDfZsYNxutp2O',theme:'dark',callback:function(token){},});});window.onloadTurnstileCallback=function(){turnstile.render('#cf-container',{sitekey:'0x4AAAAAAADMDfZsYNxutp2O',theme:'dark',callback:function(token){},});}
waitForElm('#verifiedPanel').then((elm)=>{const alertElement=document.querySelector('.alert');if(document.cookie.includes('alertClicked=true')){alertElement.style.display='none';}
function setCookie(name,value,days){const date=new Date();date.setTime(date.getTime()+(days*24*60*60*1000));const expires='; expires='+date.toUTCString();document.cookie=name+'='+value+expires+'; path=/';}
function handleAlertClose(){setCookie('alertClicked','true',5);alertElement.style.display='none';console.log('Event listener added');}
const closeButton=alertElement.querySelector('.btn-close');console.log(closeButton);closeButton.addEventListener('click',handleAlertClose);$("#showAdvanced").on("click",function(){$("i",this).toggleClass("bxs-chevron-down bxs-chevron-up");})
let scriptReadyInput=$("#ready-script");let scriptReadyHolder=$("#scriptReadyHolder");let uploadHeader=$("#uploadHeader");let goToPost=$("#goToPost")
$(scriptReadyInput).click(function(){var inputFieldValue=$(this);copyToClipboard(inputFieldValue);toast("Url copied to clipboard!","successToast");});$("#uploadAnother").on("click",function(){let uploadForm=$("form[name='uploadScript']");scriptReadyHolder.fadeOut();uploadHeader.fadeIn();uploadForm.fadeIn();uploadForm.trigger("reset");})
$("form[name='uploadScript']").on("submit",function(ev){let uploadB=$("#uploadButton")
let loaderB=$("#post_script_loader");let uploadForm=$(this);loaderB.show();uploadB.toggleClass("btn-success btn-outline-secondary")
uploadB.prop("disabled",true);NProgress.start()
ev.preventDefault();var formData=new FormData(this);$.ajax({type:'POST',url:'/postHandler',data:formData,success:function(msg){let split=msg.split(",");let insert_id=split[1];let seoTitle=split[2];if(split[0]=="success"){toast("Script uploaded!","successToast")
uploadHeader.fadeToggle();let scriptUrl=baseUrl+"/script/"+seoTitle+"-"+insert_id;scriptReadyInput.val(scriptUrl);goToPost.attr("href",scriptUrl)
uploadForm.fadeToggle();scriptReadyHolder.fadeToggle();}else{toast(msg,"errorToast")}},error:function(xhr,status,error){if(xhr.status==413){toast("Error: Image files over 1MB will be rejected by the server!","errorToast")}},complete:function(){NProgress.done();uploadB.toggleClass("btn-success btn-outline-secondary")
uploadB.prop("disabled",false);loaderB.hide();turnstile.reset()},cache:false,contentType:false,processData:false})})})
NProgress.done();document.title=uploadText;}
function copyToClipboard(text){text.select();document.execCommand("copy");}
function loadAllScripts(user){var data=localStorage.getItem("patched");if(data=="true"){$("#patchedSwitch").prop("checked",true);}
$("#patchedSwitch").prop('checked',data=='true').change(function(){localStorage.patched=$(this).prop("checked");refreshScripts();});var data2=localStorage.getItem("paid");if(data2=="true"){$("#paidSwitch").prop("checked",true);}
$("#paidSwitch").prop('checked',data2=='true').change(function(){localStorage.paid=$(this).prop("checked");refreshScripts();});var data3=localStorage.getItem("mobile");if(data3=="true"){$("#mobileSwitch").prop("checked",true);}
$("#mobileSwitch").prop('checked',data3=='true').change(function(){localStorage.mobile=$(this).prop("checked");refreshScripts();});function refreshScripts(){$("#scriptgrid").empty();var url_string=window.location.href
var url=new URL(url_string);var c=url.searchParams.get("q");start=0
if(c){loadScriptsSearch(limit,start,c)}else{loadScripts(limit,start);}}
$('#filter').change(function(){$("#scriptgrid").empty();var url_string=window.location.href
var url=new URL(url_string);var c=url.searchParams.get("q");start=0
if(c){loadScriptsSearch(limit,start,c)}else{loadScripts(limit,start);}});var button=$('#loadMore');function disableButton(){button.text("No More Data Found");button.removeClass("btn-primary");button.removeClass("shadow-primary");button.addClass("btn-danger");button.prop("disabled",true);}
function enableButton(){button.text("Show More");button.removeClass("btn-danger");button.addClass("btn-primary");button.addClass("shadow-primary");button.prop("disabled",false);}
$("#filter").change(function(){var selected=$(this).val();setQueryStringParameter("filter",selected);});var url_string=window.location.href
var url=new URL(url_string);var c=url.searchParams.get("filter");if(filter){$('#filter option[value='.concat(c).concat(']')).attr('selected','selected');}
function loadScripts(limit,start){loadScriptsTemplate();if($("p.h2.text-center.mt-5").length){$("p.h2.text-center.mt-5").remove();}
$("#loadMore").text("Loading...");var filter=$('#filter option:selected').val();var hidePatched=0;if($('#patchedSwitch').is(':checked')){var hidePatched=1;}
var hidePaid=0;if($('#paidSwitch').is(':checked')){var hidePaid=1;}
var mobileOnly=0;if($('#mobileSwitch').is(':checked')){var mobileOnly=1;}
let isUser=0;if(user!==undefined){isUser=user;}
$("#loadMore").show();NProgress.start();$.ajax({url:baseUrl.concat("/backend?v=1.2"),method:"POST",data:{limit:limit,start:start,patched:hidePatched,paid:hidePaid,mobile:mobileOnly,filter:filter,user:isUser},cache:false,success:function(data){let obj=JSON.parse(data)
var item=obj.output;$('.script-template').remove();if(item!=='000'){$('#scriptgrid').append(item);}
if(start<8&&item!=='000'){action='active';enableButton();NProgress.done();}else if(item=='000'){disableButton();$("<p class='h2 text-center mt-5'>No scripts found 😔</p>").insertAfter("#scriptgrid");action='active';NProgress.done();}else{enableButton();action="active";NProgress.done();}
if(obj.num<16){$("#loadMore").hide();}
NProgress.done();}});}
function loadScriptsSearch(limit,start,term){loadScriptsTemplate();if($("p.h2.text-center.mt-5").length){$("p.h2.text-center.mt-5").remove();}
NProgress.start();$("#loadMore").text("Loading...");var filter=$('#filter option:selected').val();var hidePatched=0;if($('#patchedSwitch').is(':checked')){var hidePatched=1;}
var hidePaid=0;if($('#paidSwitch').is(':checked')){var hidePaid=1;}
var mobileOnly=0;if($('#mobileSwitch').is(':checked')){var mobileOnly=1;}
let isUser=0;if(user!==undefined){isUser=user;}
$("#loadMore").show();$.ajax({url:"/backend?v=1.2",method:"POST",data:{limit:limit,start:start,patched:hidePatched,paid:hidePaid,mobile:mobileOnly,search:term,filter:filter,user:isUser},cache:false,success:function(data){let obj=JSON.parse(data)
var item=obj.output;$('.script-template').remove();if(item!=='000'){$('#scriptgrid').append(item);}
if(start<8&&item!=='000'){action='active';enableButton();NProgress.done();}else if(item=='000'){disableButton();$("<p class='h2 text-center mt-5'>No scripts found 😔</p>").insertAfter("#scriptgrid");action='active';NProgress.done();}else{enableButton();action="active";NProgress.done();}
if(obj.num<16){$("#loadMore").hide();}
NProgress.done();}});}
var url_string=window.location.href
var url=new URL(url_string);var c=url.searchParams.get("q");if(c){loadScriptsSearch(limit,start,c)
searchModifier()
$("#searchBar").val(c)}else{loadScripts(limit,start);}
$("#loadMore").on('click',function(){action='active';start=start+limit;loadScriptsTemplate();if(window.location.href.indexOf("?q")){var url_string=window.location.href
var url=new URL(url_string);var c=url.searchParams.get("q");$('#spinner').show();loadScriptsSearch(limit,start,c)
$('#spinner').hide();}else{$('#spinner').show();loadScripts(limit,start);$('#spinner').hide();}})
function searchModifier(){if(searchMod){$(".titlePage").remove();$(".descriptionPage").remove();$("#searchHolder").removeClass("mt-20");$("#searchHolder").addClass("mt-15");$(".headerBox").removeClass("vh-100");$(".headerBox").height("30vh");$("#sbox").removeClass("mb-5");$("#userCount").remove();$("#sbox").css("bottom","10vh");$("#scriptScroller").remove();window.scrollTo({top:0,behavior:'smooth'});}else{}}
$("#searchBar").on("focus",function(){$('.result').on('mousedown',function(event){event.preventDefault();});searchModifier()
var inputVal=$(this).val();var resultDropdown=$(this).siblings(".result");var userSearch=0;if(searchMod==false){var url=window.location.href
var username=url.split("/").pop()
userSearch=username.split('?')[0];}
if(inputVal.length){$.get("/ajaxSearch?v=1.1",{term:inputVal,user:userSearch}).done(function(data){resultDropdown.html(data);});}else{resultDropdown.empty();}})
let debounceSearch;$("#searchBar").on("input",function(){clearTimeout(debounceSearch);debounceSearch=setTimeout(()=>{NProgress.start()
$('.result').on('mousedown',function(event){event.preventDefault();});var that=this,value=$(this).val();if(value==""){$("#scriptgrid").empty();setQueryStringParameter("q","");if(searchMod==false){var url=window.location.href
var username=url.split("/").pop()
userSearch=username.split('?')[0];loadUser(userSearch);}else{loadScripts(16,0)}}else{setQueryStringParameter("q",value);}
var inputVal=$(this).val();var resultDropdown=$(this).siblings(".result");var userSearch=0;if(searchMod==false){var url=window.location.href
var username=url.split("/").pop()
userSearch=username.split('?')[0];}
if(inputVal.length){$.get("/ajaxSearch",{term:inputVal,user:userSearch}).done(function(data){resultDropdown.html(data);NProgress.done()});}else{resultDropdown.empty();}
NProgress.done();},150);});$("#clearButton").on("click",function(){$('#searchBar').val('')
$("#scriptgrid").empty();setQueryStringParameter("q","");if(searchMod==false){var url=window.location.href
var username=url.split("/").pop()
userToSearch=username.split('?')[0];loadUser(userToSearch);}else{loadScripts(16,0)}})
$("#searchButton").on("click",function(){startSearch();})
function startSearch(){document.querySelectorAll('.resultList').forEach(e=>e.remove());start=0;action='active';$("#scriptgrid").empty();var url_string=window.location.href
var url=new URL(url_string);var c=url.searchParams.get("q");loadScriptsSearch(limit,start,c);}
$("#searchBar").on("focusout",function(){document.querySelectorAll('.resultList').forEach(e=>e.remove());})
$('#searchBar').on("keypress",function(e){if(e.which==13){startSearch();}});}
function loadContent(){searchMod=true;loadScriptsTemplate();NProgress.done();loadScriptAds(3);document.title=homeText;var limit=16;var start=0;waitForElm('#scriptgrid').then((elm)=>{loadLayout();loadAllScripts()})}
function loadLayout(){var preferredLayout=localStorage.getItem("layout");if(preferredLayout==="list-layout"){$("#scriptgrid").addClass("list-layout");}
$("#gridLayout").on("click",function(){$("#scriptgrid").removeClass("list-layout");localStorage.setItem("layout","");});$("#listLayout").on("click",function(){$("#scriptgrid").addClass("list-layout");localStorage.setItem("layout","list-layout");});}
$(document).ready(function(){$("#x").on("click",function(){$(".adHolder").remove();})
var body=$('body');body.on('mouseover','[data-bs-toggle="tooltip"]',function(e){e.stopPropagation();return new bootstrap.Tooltip(this).show();});body.on('mouseleave','[data-bs-toggle="tooltip"]',function(e){$('[role="tooltip"]').fadeOut(function(){$(this).remove();e.stopPropagation();});});})
function toast(text,classname){Toastify({text:text,duration:3000,className:classname,newWindow:true,close:false,gravity:"bottom",position:"left",stopOnFocus:true,}).showToast();}
function loadUser(){loadLayout();searchMod=false;var url=window.location.href
var username=url.split("/").pop()
username=username.split('?')[0];userAdjust();start=0;loadAllScripts(username);NProgress.done()}
function userAdjust(){$("#showAdvanced").on("click",function(){$("i",this).toggleClass("bxs-chevron-down bxs-chevron-up");})
$("#uploadSomething").on("click",function(){if($("#upload").parent().hasClass("active")){return;}
loadUpload();window.history.pushState("upload","upload",baseUrl.concat("/upload"));})
loadScriptAds(6);$("#profileStatus").on("focusin",function(){$("#statusButton").show();})
$("#profileStatus").keypress(function(e){return e.which!=13;});var timeoutFlag=false;$("#profileStatus").on("focusout",function(){if(timeoutFlag==false){timeoutFlag=true;setTimeout(function(){$("#statusButton").hide();timeoutFlag=false;},2000)}})
$("#statusButton").on("click",function(){let statusText=$("#profileStatus").text();$.post("/postHandler",{updateStatus:1,text:statusText}).done(function(msg){if(msg=="success"){toast("Status updated!","successToast");}else{toast("Error: "+msg,"errorToast");}})})
$("form[name='banForm']").on("submit",function(ev){ev.preventDefault();NProgress.start();let banButton=$("#banButton");let toBan=$("#banButton").data("toban");banButton.prop("disabled",true);var formData=new FormData(this);formData.append("ban",1);formData.append("toBan",toBan);$.ajax({type:'POST',url:'/postHandler',data:formData,processData:false,contentType:false,success:function(msg){if(msg=="success"){toast("User successfully banned!","successToast");loadUser(toBan);}else if(msg=="unbanned"){toast("User successfully unbanned!","successToast")
loadUser(toBan);}else{toast("Error: "+msg,"errorToast");}
banButton.prop("disabled",false);NProgress.done();}})})
submitEditChanges(true);$("#verifyButton").on("click",function(){let b=$(this);NProgress.start();b.prop("disabled",true);let username=b.data("toverify");$.post("/postHandler",{verify:1,toVerify:username}).done(function(msg){if(msg=="verified"){toast("User successfully verified","successToast");loadUser(username);}else if(msg=="unverified"){toast("User successfully unverified","successToast");loadUser(username);}else{toast(msg,"errorToast");}
NProgress.done();b.prop("disabled",false);})})}
function submitEditChanges(reloadScripts){$("form[name='editScript']").on("submit",function(ev){let uploadB=$("#editButton")
let loaderB=$("#post_script_loader");let s_id=$("#editForm").data("postid");loaderB.show();uploadB.toggleClass("btn-success btn-outline-secondary")
uploadB.prop("disabled",true);NProgress.start()
ev.preventDefault();var formData=new FormData(this);formData.append("s_id",s_id);formData.append("edit",1);$.ajax({type:'POST',url:'/postHandler',data:formData,success:function(msg){if(msg=="success"){toast("Script updated!","successToast")
$("#scriptgrid").empty();var url=window.location.href
var username=url.split("/").pop()
username=username.split('?')[0];if(reloadScripts){loadAllScripts(username);}else{const curUrl=window.location.href;$("#main-no-modals").load(curUrl.concat("#main-no-modals > *"),function(){window.scrollTo(0,0);NProgress.done();window.history.pushState('script','',curUrl);loadTitle();loadScriptAds(2);commentStart=0;commentLimit=5;loadComments(commentStart,commentLimit);scriptButton();})}
editPost(s_id);}else{toast(msg,"errorToast")}
NProgress.done();uploadB.toggleClass("btn-success btn-outline-secondary")
uploadB.prop("disabled",false);loaderB.hide();turnstile.reset()},cache:false,contentType:false,processData:false})})}
function loadFormAdjustments(){const inputs=document.querySelectorAll(".minRequirement");inputs.forEach(input=>{input.addEventListener("input",function(){const minlength=this.getAttribute("minlength");const span=this.previousElementSibling.querySelector("span");if(span){if(this.value.length>=minlength){span.innerHTML=`(${this.value.length}/${minlength})`;span.style.color="green";}else{span.innerHTML=`(${this.value.length}/${minlength})`;span.style.color="red";}}});});const tagFields=document.querySelectorAll(".tagFunction");const tagLists=document.querySelectorAll(".tag-list");tagFields.forEach(function(elem,index){elem.addEventListener("input",function(){let tags=elem.value.split(",");let tagList=tagLists[index];tagList.innerHTML="";tags.forEach(function(tag){tag=tag.trim();if(tag.length>0){let tagItem=document.createElement("span");tagItem.classList.add("list-group-item");tagItem.textContent=tag;tagList.appendChild(tagItem);}});});});}
function editPost(script_id){let scriptId=script_id
loadFormAdjustments();$("#modal_spinner").show();$("#imgPreview").hide();$("#modal_status").text("Preparing content, please wait...");$("#modalContent").hide();$("#editForm").data("postid",scriptId);$("#universalScript").change(function(){if(this.checked){$("#gamelink").prop("disabled",true)}else{$("#gamelink").prop("disabled",false)}})
if(typeof someObject=='undefined')$.loadScript('https://challenges.cloudflare.com/turnstile/v0/api.js',function(){turnstile.render('#cf-container',{sitekey:'0x4AAAAAAADMDfZsYNxutp2O',theme:'dark',callback:function(token){},});});window.onloadTurnstileCallback=function(){turnstile.render('#cf-container',{sitekey:'0x4AAAAAAADMDfZsYNxutp2O',theme:'dark',callback:function(token){},});}
$.post("/postHandler",{editFields:1,s_id:scriptId}).done(function(msg){if(isJsonString(msg)){let obj=JSON.parse(msg);$("#title").val(obj["title"]);$("#gamelink").val(obj["game_link"]);$("#desc").val(obj["description"]);$("#script").val(obj["script"]);let hashtags=obj["hashtags"];if(hashtags&&hashtags.charAt(0)==","){hashtags=hashtags.substring(1)}
let features=obj["features"];if(features&&features.charAt(0)==","){features=features.substring(1)}
$("#hashtags").val(hashtags);$("#features").val(features);$("#discord").val(obj["discord"]);if(obj["game_link"]=="universal"){$("#universalScript").prop("checked",true);$("#gamelink").attr("disabled",true)}
if(obj["key"]==1){$("#keysys").prop("checked",true)}else{$("#keysys").prop("checked",false)}
if(obj["mobile"]==1){$("#mobile").prop("checked",true)}else{$("#mobile").prop("checked",false)}
if(obj["paid"]==1){$("#paid").prop("checked",true)}else{$("#paid").prop("checked",false)}
if(obj["patched"]==1){$("#patched").prop("checked",true)}else{$("#patched").prop("checked",false)}
if(obj["private"]==0){$("#private").prop("checked",true)}else{$("#private").prop("checked",false)}
let image;if(obj["image"]==null||obj["image"]==""){image=obj["rbximage"]}else{image="/images/"+obj["image"]}
$("#imgPreview").attr("src",image);$("#modal_spinner").hide();$("#imgPreview").show();$("#modalContent").show();$("#modalContent").show();$("#modal_status").text(obj["title"]);}else{alert("Something went wrong: "+msg);}})}
function isJsonString(str){try{JSON.parse(str);}catch(e){return false;}
return true;}
function loadUserPage(obj){searchMod=false;NProgress.start();var someurl=$(obj).attr("href");$("#main-page").load(someurl.concat(" #main-page > *"),function(){userAdjust();window.scrollTo(0,0);window.history.pushState('user','',someurl);start=0;loadAllScripts(someurl.split("/").pop());NProgress.done();})
return false;}
function contentDisp(obj){NProgress.start();var someurl=$(obj).attr("href");$("#main-page").load(someurl.concat(" #main-page > *"),function(){window.scrollTo(0,0);NProgress.done();window.history.pushState('script','',someurl);loadTitle();loadScriptAds(2);commentStart=0;commentLimit=5;loadComments(commentStart,commentLimit);scriptButton();})
return false;}
function loadTitle(){waitForElm('#scriptframe').then((elm)=>{document.title=$("#title").text();})}
function countDownload(){waitForElm('#copyButton').then((elm)=>{$("#downloadExternal").one("click",function(){var url=window.location.href
var id=url.split("-").pop()
$.ajax({url:baseUrl.concat("/getScript"),method:"POST",data:{id:id},cache:false,success:function(data){if(data!==""){}else{toast("Script likely no longer available, sorry!","errorToast");}}})})})}
function CopyToClipboard(containerid){var container=document.getElementById(containerid);if(!container){return;}
var range=document.createRange();range.selectNode(container);window.getSelection().removeAllRanges();window.getSelection().addRange(range);document.execCommand("copy");}
function scriptLoaderButton(){$("#copyScript").on("click",function(){var self=this;CopyToClipboard("theScript")
$("i",self).toggleClass('bx-copy-alt bx-check')
toast("Script copied!","successToast")
setTimeout(function(){$("i",self).toggleClass('bx-copy-alt bx-check')},1500);});$("#loadScript").one("click",()=>{var url=window.location.href
var id=url.split("-").pop()
$.post("/postHandler",{getScript:1,s_id:id}).done((res)=>{$("#theScript").append(res)
if(typeof someObject=='undefined')$.loadScript('/assets/js/prism.js',function(){});})
loadScriptAds(4);})
window.addEventListener('popstate',function(){$('body').removeClass('modal-open').removeAttr('style');$(".modal-backdrop").removeClass("modal-backdrop");});}
function loadComments(cStart,cLimit){var url=window.location.href
var id=url.split("-").pop()
var noComments=$("#noComments")
$("#moreComments").hide();$(".commentTextarea").each(function(){this.setAttribute("style","height:"+(this.scrollHeight)+"px;overflow-y:hidden;");}).on("input",function(){this.style.height=0;this.style.height=(this.scrollHeight)+"px";});$("#comment_loader").show();noComments.hide()
$.post("/postHandler",{s_id:id,comments:1,start:cStart,limit:cLimit}).done(function(msg){if(isJsonString(msg)){let obj=JSON.parse(msg);$("#allComments").append(obj.output);if(obj.num>=5){$("#moreComments").show();}}else{if($("div.comment").length>0){noComments.text("There aren't any more comments")}
noComments.show()
$("#moreComments").hide();}
$("#comment_loader").hide();let voteType="";})}
function LikeComment(obj,theCid){voteType=1;c_id=theCid;let likeCountElement=$("#commentLikeText"+c_id);let dislikeCountElement=$("#commentDislikeText"+c_id);let commentDislikeButton=$("#commentDislikeButton"+c_id);var url=window.location.href
var id=url.split("-").pop()
let rateState=0
if($(obj).hasClass("bxs-like")){voteType=0;rateState=1}
NProgress.start();if(voteType!==""){$.post("/postHandler",{c_id:c_id,voteType:voteType,s_id:id,commentVote:1}).done(function(data){if(data!=="success"){if(data=="noauth"){loadLogin();}else{alert("An error has occured: "+data);}}else{if(rateState==1){toast("Comment Like Removed","basicToast");}else{toast("Comment Liked","basicToast");}}
NProgress.done();})}
if(commentDislikeButton.hasClass("bxs-dislike")){commentDislikeButton.toggleClass("bx-dislike bxs-dislike");dislikeCountElement.html(function(i,val){return val*1-1});}
if($(obj).hasClass("bx-like")){likeCountElement.html(function(i,val){return val*1+1});}else{likeCountElement.html(function(i,val){return val*1-1});}
$(obj).toggleClass("bx-like bxs-like");}
function DislikeComment(obj,theCid){voteType=2;c_id=theCid;let likeCountElement=$("#commentLikeText"+c_id);let dislikeCountElement=$("#commentDislikeText"+c_id);let commentLikeButton=$("#commentLikeButton"+c_id);let rateState=0
if($(obj).hasClass("bxs-dislike")){voteType=0;rateState=1}
NProgress.start();if(voteType!==""){$.post("/postHandler",{c_id:c_id,voteType:voteType,commentVote:1}).done(function(data){if(data!=="success"){if(data=="noauth"){loadLogin();}else{alert("An error has occured: "+data);}}else{if(rateState==1){toast("Comment Like Removed","basicToast");}else{toast("Comment Liked","basicToast");}}
NProgress.done();})}
if(commentLikeButton.hasClass("bxs-like")){commentLikeButton.toggleClass("bx-like bxs-like");likeCountElement.html(function(i,val){return val*1-1});}
if($(obj).hasClass("bx-dislike")){dislikeCountElement.html(function(i,val){return val*1+1});}else{dislikeCountElement.html(function(i,val){return val*1-1});}
$(obj).toggleClass("bx-dislike bxs-dislike");}
function DeleteComment(comment_obj,comment_id){let commentObj=comment_obj;let c_id=comment_id;$.post("/postHandler",{deleteComment:1,c_id:c_id}).done(function(msg){if(msg=="success"){commentObj.fadeToggle();toast("Comment deleted!","successToast");}else{toast("Something went wrong "+msg,"errorToast");}})}
function ReplyComment(name){$("#commentInput").val(function(){$("#commentInput").focus();let space=this.value.length>0?" @":"@";return this.value+space+name+" ";})}
function replyTo(name){var targetOffset=$('#commentInput').offset().top;$('html, body').animate({scrollTop:targetOffset},1000);}
jQuery.loadScript=function(url,callback){jQuery.ajax({url:url,dataType:'script',success:callback,async:true});}
function scriptButton(){waitForElm('#reportButton').then((elm)=>{$("#initDownload").one('click',()=>{var currentUrl=window.location.href;var id=currentUrl.split("-").pop();$.post('/getScript',{verifyDownload:1,s_id:id})})
$("#readmore").on("click",function(){$(this).hide();let readMoreText=$("#readmoreText");let dotdotdot=$("#dotdotdot");dotdotdot.toggle();readMoreText.toggle();})
$("#moreComments").on("click",function(){commentStart=commentStart+commentLimit
loadComments(commentStart,commentLimit)})
$("#loginLink").on("click",function(){loadLogin();window.history.pushState("login","login",baseUrl.concat("/login"));})
let likeCountElement=$("#likeCount")
let dislikeCountElement=$("#dislikeCount")
let voteType="";$("#likeButton").on("click",function(){voteType=1;let rateState=0
if($("i",this).hasClass("bxs-like")){voteType=0;rateState=1}
let id=$(this).data("postid");NProgress.start();if(voteType!==""){$.post("/postHandler",{s_id:id,voteType:voteType,postVote:1}).done(function(data){if(data!=="success"){if(data=="noauth"){loadLogin();}else{alert("An error has occured: "+data);}}else{if(rateState==1){toast("Like Removed","basicToast");}else{toast("Script Liked","basicToast");}}
NProgress.done();})}
if($("i","#dislikeButton").hasClass("bxs-dislike")){$("i","#dislikeButton").toggleClass("bx-dislike bxs-dislike");dislikeCountElement.html(function(i,val){return val*1-1});}
if($("i",this).hasClass("bx-like")){likeCountElement.html(function(i,val){return val*1+1});}else{likeCountElement.html(function(i,val){return val*1-1});}
$("i",this).toggleClass("bx-like bxs-like");})
$("#dislikeButton").on("click",function(){voteType=2;let rateState=0;if($("i",this).hasClass("bxs-dislike")){voteType=0;rateState=1;}
let id=$(this).data("postid");NProgress.start();if(voteType!==""){$.post("/postHandler",{s_id:id,voteType:voteType,postVote:1}).done(function(data){if(data!=="success"){if(data=="noauth"){loadLogin();}else{alert("An error has occured: "+data);}}else{if(rateState==1){toast("Dislike Removed","basicToast");}else{toast("Script Disliked","basicToast");}}
NProgress.done();})}
if($("i","#likeButton").hasClass("bxs-like")){$("i","#likeButton").toggleClass("bx-like bxs-like");likeCountElement.html(function(i,val){return val*1-1});}
if($("i",this).hasClass("bx-dislike")){dislikeCountElement.html(function(i,val){return val*1+1});}else{dislikeCountElement.html(function(i,val){return val*1-1});}
$("i",this).toggleClass("bx-dislike bxs-dislike");})
$("#saveButton").on("click",function(){NProgress.start();let button=$(this);let saveText=$("#saveText");button.prop("disabled",true);let id=$(this).data("postid");$.post("/postHandler",{s_id:id,save:1}).done(function(msg){if(msg=="noauth"){loadLogin();}else if(msg=="successDelete"){toast("Removed script from save list","basicToast");$("i",button).toggleClass("bxs-save bx-check")
saveText.text("Save");}else if(msg=="successSave"){toast("Saved script","basicToast");$("i",button).toggleClass("bxs-save bx-check")
saveText.text("Saved");}else{toast(msg,"errorToast");}
button.prop("disabled",false);NProgress.done();})})
if(typeof someObject=='undefined')$.loadScript('//d1nubxdgom3wqt.cloudfront.net/?xbund=958688',function(){});if(typeof someObject=='undefined')$.loadScript('/assets/js/prism.js',function(){});if(typeof someObject=='undefined')$.loadScript('https://rscripts.net/antiAsolution.js',function(){});var commentInput=$("#commentInput");if(commentInput){var flag=true
commentInput.keyup(function(){if($(this).val()){if(flag){flag=false}
$("#commentPostButton").show();}else{$("#commentPostButton").hide();}})
$("#commentPostButton").on("click",function(){var postButton=$(this);var loader=$("#post_comment_loader")
var s_id=postButton.data("postid");postButton.prop("disabled",true);loader.show();NProgress.start()
$.post("/postHandler",{comment:commentInput.val(),s_id:s_id}).done(function(data){var success=data=="querySuccess"
if(success){toast("Comment Posted","basicToast");$("#allComments").empty();commentInput.val('');$("#commentPostButton").hide();$("#commentCount").text(function(index,currentText){return parseInt(currentText)+1;});commentStart=0;loadComments(commentStart,commentLimit);}else{toast(data,"errorToast");}
loader.hide();postButton.prop("disabled",false);NProgress.done();})})}
submitEditChanges(false);scriptLoaderButton();countDownload()
$("#reportButton").on("click",function(){NProgress.start();$(this).prop("disabled",true);$(this).text("Loading...");var url=window.location.href
var id=url.split("-").pop()
var reason=$("#reason option:selected").text();var gresponse=grecaptcha.getResponse();if(gresponse.length>0){$.ajax({url:baseUrl.concat("/submitReport"),method:"POST",data:{reason:reason,id:id,response:gresponse},cache:false,success:function(data){if(data=="001"){$("#reportButton").removeClass("btn-danger");$("#reportButton").addClass("btn-success");$("#reportButton").text("Done, thank you!");NProgress.done();}else{$("#reportButton").prop("disabled",false);$("#reportButton").text("Try again");NProgress.done();}}})}else{$(this).prop("disabled",false);$(this).text("Please do the captcha!");}})})}
function loadCaptcha(){waitForElm('#reportButton').then((elm)=>{$("#mainReport").one("click",function(){asyncCaptcha('captcha_container','#captcha_status','#reportButton')})})}
function asyncCaptcha(container,captchaStatusField,buttonDisable){if(buttonDisable){$(buttonDisable).prop("disabled",true)}
try{if(typeof grecaptcha!=="undefined"){grecaptcha.ready(function(){var siteKey='6Le2Z7MaAAAAAM2UgYd6OHv-oqJ_D3vYpPKqtWVI';setTimeout(function(){try{grecaptcha.render(container,{'sitekey':siteKey,'theme':"dark"});$(captchaStatusField).toggle();if(buttonDisable){$(buttonDisable).prop("disabled",false)}}catch(error){}},1000);});}}catch(error){}
if(typeof loadedRecaptcha!='undefined'){return;}
jQuery.getScript("https://www.google.com/recaptcha/api.js").done(function(script,textStatus){if(typeof grecaptcha!=="undefined"){grecaptcha.ready(function(){var siteKey='6Le2Z7MaAAAAAM2UgYd6OHv-oqJ_D3vYpPKqtWVI';setTimeout(function(){try{grecaptcha.render(container,{'sitekey':siteKey,'theme':"dark"});$(captchaStatusField).toggle();if(buttonDisable){$(buttonDisable).prop("disabled",false)}}catch(error){}},1000);});}
loadedRecaptcha=true;});}
function setQueryStringParameter(name,value){const params=new URLSearchParams(window.location.search);params.set(name,value);window.history.replaceState({},"",decodeURIComponent(`${window.location.pathname}?${params}`));}
function loadScriptAds(value){waitForElm('#scriptgrid').then((elm)=>{jQuery.loadScript=function(url,callback){jQuery.ajax({url:url,dataType:'script',success:callback,async:true});}
if(typeof someObject=='undefined')$.loadScript('https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2192724296802940',function(){if(value==2){$(".googleAd1").each(function(){$(this).append('<ins class="adsbygoogle responsiveAd" style="display:block" data-ad-client="ca-pub-2192724296802940" data-ad-slot="2260047238"></ins>');(adsbygoogle=window.adsbygoogle||[]).push({});});$(".googleAd3").each(function(){$(this).append('<ins class="adsbygoogle" style="display:inline-block;width:300px;height:250px" data-ad-client="ca-pub-2192724296802940" data-ad-slot="7018771086"></ins>');(adsbygoogle=window.adsbygoogle||[]).push({});});$(".googleAd4").each(function(){$(this).append('<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-2192724296802940" data-ad-slot="8794006270" data-ad-format="auto" data-full-width-responsive="true"></ins>');(adsbygoogle=window.adsbygoogle||[]).push({});});$(".googleAd5").each(function(){$(this).append('<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-2192724296802940" data-ad-slot="1273860161" data-ad-format="auto" data-full-width-responsive="true"></ins>');(adsbygoogle=window.adsbygoogle||[]).push({});});}else if(value==3){$(".googleAd3").each(function(){$(this).append('<ins class="adsbygoogle" style="display:inline-block;width:300px;height:250px" data-ad-client="ca-pub-2192724296802940" data-ad-slot="7018771086"></ins>');(adsbygoogle=window.adsbygoogle||[]).push({});});}else if(value==4){$(".modalAd").each(function(){$(this).append('<ins class="adsbygoogle responsiveAd" style="display:block" data-ad-client="ca-pub-2192724296802940" data-ad-slot="2260047238"></ins>');$(document).ready(function(){(adsbygoogle=window.adsbygoogle||[]).push({})})});}else if(value==5){$(".bottomAd").each(function(){$(this).append('<ins class="adsbygoogle responsiveAd" style="display:block" data-ad-client="ca-pub-2192724296802940" data-ad-slot="2260047238"></ins>');$(document).ready(function(){(adsbygoogle=window.adsbygoogle||[]).push({})})});}else if(value==6){$(".googleAd1").each(function(){$(this).append('<ins class="adsbygoogle responsiveAd" style="display:block" data-ad-client="ca-pub-2192724296802940" data-ad-slot="2260047238"></ins>');(adsbygoogle=window.adsbygoogle||[]).push({});});}else if(value==7){$(".googleAd1").each(function(){$(this).append('<ins class="adsbygoogle responsiveAd" style="display:block" data-ad-client="ca-pub-2192724296802940" data-ad-slot="2260047238"></ins>');(adsbygoogle=window.adsbygoogle||[]).push({});});$(".googleAd3").each(function(){$(this).append('<ins class="adsbygoogle" style="display:inline-block;width:300px;height:250px" data-ad-client="ca-pub-2192724296802940" data-ad-slot="7018771086"></ins>');(adsbygoogle=window.adsbygoogle||[]).push({});});}else{$(".googleAd3").each(function(){$(this).append('<ins class="adsbygoogle" style="display:inline-block;width:300px;height:250px" data-ad-client="ca-pub-2192724296802940" data-ad-slot="7018771086"></ins>');$(document).ready(function(){(adsbygoogle=window.adsbygoogle||[]).push({})})});}});})}
function waitForElm(selector){return new Promise(resolve=>{if(document.querySelector(selector)){return resolve(document.querySelector(selector));}
const observer=new MutationObserver(mutations=>{if(document.querySelector(selector)){resolve(document.querySelector(selector));observer.disconnect();}});observer.observe(document.body,{childList:true,subtree:true});});}